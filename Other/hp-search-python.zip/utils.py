import tensorflow as tf
from loguru import logger
import numpy as np
from tensorflow.keras.datasets import cifar10, mnist


def set_gpu_config():
    # Set up GPU config
    physical_devices = tf.config.experimental.list_physical_devices("GPU")
    if physical_devices:
        logger.info("Setting up GPU")
        for device in physical_devices:
            tf.config.experimental.set_memory_growth(device, True)
    else:
        logger.info("Did not find GPU resources")


def load_data(source="mnist"):
    if source == "mnist":
        logger.info("Experimenting with MNIST data")

        (x_train, y_train), (x_test, y_test) = mnist.load_data()

        # MNIST only has one color channel, while cifar has 3. That makes a mismatch. Just reshape tensors to
        # make the color-channel explicit for MNIST, too...
        x_train = np.expand_dims(x_train, axis=-1)
        x_test = np.expand_dims(x_test, axis=-1)
        y_train = np.expand_dims(y_train, axis=-1)
        y_test = np.expand_dims(y_test, axis=-1)

        # Further, MNIST is a bit too simple for the difference between HPs to be
        # evident, so I'll use only the first few examples ...
        x_train = x_train[:500]
        y_train = y_train[:500]

    elif source == "cifar":
        logger.info("Experimenting with CIFAR data")
        (x_train, y_train), (x_test, y_test) = cifar10.load_data()

    else:
        raise ValueError(f"Problems in load_data.load_data. Did not recognize dataset {source}")

    x_train = x_train.astype('float32') / 255.
    x_test = x_test.astype('float32') / 255.
    return x_test, x_train, y_test, y_train
